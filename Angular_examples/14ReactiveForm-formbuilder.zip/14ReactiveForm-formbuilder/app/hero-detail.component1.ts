import { Component,Input, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import {  Address, Hero,states } from './data-model';

@Component({
  selector: 'hero-detail1',
  templateUrl: './hero-detail.component1.html'
})

export class HeroDetailComponent1 implements OnChanges {
  heroForm: FormGroup; // <--- heroForm is of type FormGroup
  @Input() hero: Hero;
  states:string[] = states;
  
  constructor(private fb: FormBuilder) { // <--- inject FormBuilder
    
    this.createForm();
  }

  createForm() {
   // this.heroForm = this.fb.group({
   //  name: '', // <--- the FormControl called "name"
   // });
   
   this.heroForm = this.fb.group({
        name: ['', Validators.required ],
       address: this.fb.group({ // <-- the child FormGroup
        street: ['', Validators.maxLength(10)],
        city: '',
        state: '',
        zip: ''
        }),
       power: '',
       sidekick: ''
    });
    

  }
  
  ngOnChanges() {
  console.log('ngonchanges called'+this.hero.name);
    this.heroForm.reset({   //this.heroForm.setValue
      name: this.hero.name,
      address: this.hero.addresses[0] || new Address()
    });
//    this.setAddresses(this.hero.addresses);
  }
  
   onSubmit() {
    if (this.heroForm.valid) {
      console.log("Form Submitted!");
      this.heroForm.reset();
    }
  }
}