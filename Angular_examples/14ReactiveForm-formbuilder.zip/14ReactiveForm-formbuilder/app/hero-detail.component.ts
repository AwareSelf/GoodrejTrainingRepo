import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { states } from './data-model';

@Component({
  selector: 'hero-detail',
  templateUrl: 'app/hero-detail.component.html'
})

export class HeroDetailComponent {
  heroForm: FormGroup; // <--- heroForm is of type FormGroup
  states = states;
  
  constructor(private fb: FormBuilder) { // <--- inject FormBuilder
    this.createForm();
  }

  createForm() {
   // this.heroForm = this.fb.group({
   //  name: '', // <--- the FormControl called "name"
   // });
   
   this.heroForm = this.fb.group({
        name: ['', Validators.required ],
       address: this.fb.group({ // <-- the child FormGroup
        street: '',
        city: '',
        state: '',
        zip: ''
        }),
       power: '',
       sidekick: ''
    });
  }
}