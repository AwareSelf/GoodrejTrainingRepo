"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Hero {
    constructor(id, name, power, alterEgo) {
        this.id = id;
        this.name = name;
        this.power = power;
        this.alterEgo = alterEgo;
    }
}
exports.Hero = Hero;
//# sourceMappingURL=hero.js.map