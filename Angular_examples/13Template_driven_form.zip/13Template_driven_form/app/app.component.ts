import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<hero-form></hero-form>'
})
export class AppComponent { }
