import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { BookListComponent } from './book-list/book-list.component';
import { BookComponent } from './book/book.component';
import { GreetDirective } from './greet.directive';




//Note: FormsModule is required only during two-way binding - using ngModel

@NgModule({
  declarations: [
    AppComponent,
    BookListComponent,
    BookComponent,
    GreetDirective


  ],
  imports: [
    BrowserModule,
    FormsModule],

  bootstrap: [AppComponent]
})
export class AppModule { }
