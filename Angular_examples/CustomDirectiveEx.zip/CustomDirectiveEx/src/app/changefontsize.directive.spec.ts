import { ChangefontsizeDirective } from './changefontsize.directive';

describe('ChangefontsizeDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangefontsizeDirective();
    expect(directive).toBeTruthy();
  });
});
