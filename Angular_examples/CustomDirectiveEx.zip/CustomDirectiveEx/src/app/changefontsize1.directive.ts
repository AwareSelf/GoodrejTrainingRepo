import { Directive, HostBinding, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appChangefontsize1]'
})
export class Changefontsize1Directive {

  @HostBinding('style.fontSize') fontSize!:string;

  @Input('appChangefontsize1') startingFontSize!:string;
  @Input('clkfont') onclickFontSize!:string;

  constructor() { }


  ngOnInit()
  {
    //this.fontSize = '300%';
    this.fontSize = this.startingFontSize;
  }

  @HostListener('click')
  onclick()
  {
    //this.fontSize = '100%';
    this.fontSize = this.onclickFontSize;
  }
  

}
