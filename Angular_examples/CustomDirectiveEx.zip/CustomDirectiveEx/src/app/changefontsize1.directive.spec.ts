import { Changefontsize1Directive } from './changefontsize1.directive';

describe('Changefontsize1Directive', () => {
  it('should create an instance', () => {
    const directive = new Changefontsize1Directive();
    expect(directive).toBeTruthy();
  });
});
