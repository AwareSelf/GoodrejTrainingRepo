import { Directive, Input,OnInit,HostListener,HostBinding } from '@angular/core';

@Directive({
  selector: '[appAttrCustomHostbinding1]'
})
export class AttrCustomHostbinding1Directive implements OnInit {

  @Input() defaultColor:string = 'transparent';
  @Input() highlightColor:string = 'dodgerblue';

  @HostBinding('style.backgroundColor') backgroundColor:string;

  constructor() { }

  ngOnInit()
  {
    this.backgroundColor =this.defaultColor;
  }

  @HostListener('mouseenter') mouseover(eventData:Event)
  {
     this.backgroundColor = this.highlightColor;

  }

  @HostListener('mouseleave') mouseleave(eventData:Event)
  {
    this.backgroundColor = this.defaultColor;
  }
}
