import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appAttrCustomHostbinding]'
})
export class AttrCustomHostbindingDirective {
  @HostBinding('style.backgroundColor') backgroundColor:string;

  constructor() { }

  @HostListener('mouseenter') mouseover(eventData:Event)
  {
     this.backgroundColor = 'dodgerblue';

  }

  @HostListener('mouseleave') mouseleave(eventData:Event)
  {
    this.backgroundColor = 'transparent';
  }

}
