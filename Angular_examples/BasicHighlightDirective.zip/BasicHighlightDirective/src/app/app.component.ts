import { AfterViewChecked, AfterViewInit, ChangeDetectorRef, Component,ComponentRef,ElementRef,
  OnInit, ViewChild,OnChanges,SimpleChanges,OnDestroy,AfterContentChecked,
AfterContentInit} from '@angular/core';
import { NgModel } from '@angular/forms';
import { GreetDirective} from './directives/greet.directive';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']

})
export class AppComponent implements
OnInit,
OnChanges,
AfterViewInit,
AfterViewChecked,
AfterContentInit,
AfterContentChecked,
OnDestroy{


   greetMe: string;


  @ViewChild('ip1')
  ip1!: ElementRef;

  @ViewChild(GreetDirective)
  set greetApp(dir: GreetDirective) {
    this.greetMe = dir.WhatsUp
    this.cdr.detectChanges();
  };

  constructor(private cdr: ChangeDetectorRef) {
    console.log('app-component:constructor called');
  }

  ngOnInit() {
    console.log('app-component:ngOnInit called');
    }

  ngOnChanges(changes: SimpleChanges) {
    // changes.prop contains the old and the new value...
      console.log('app-component:ngOnChanges called'+changes);
  }

  ngAfterViewInit()
  {
    console.log('app-component:ngAfterViewInit called');
   }

  ngAfterViewChecked()
  {
    console.log('app-component:ngAfterViewChecked called')
  }

  ngAfterContentInit()
  {
    console.log('app-component:ngAfterContentInit called');

  }

  ngAfterContentChecked()
  {
    console.log('app-component:ngAfterContentChecked called')
  }

  ngOnDestroy():void
  {
    console.log('app-component:ngOnDestroy called')
  }

  onShowInput(ip:HTMLInputElement):void
  {
     console.log(ip.value);
     console.log(this.ip1);
     console.log(this.ip1.nativeElement.value);
  }

}

