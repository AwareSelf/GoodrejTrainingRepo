import { CustomAttrDirective } from './custom-attr.directive';

describe('CustomAttrDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomAttrDirective();
    expect(directive).toBeTruthy();
  });
});
