import { Directive,ElementRef,Renderer2} from '@angular/core';

@Directive({
  selector: '[appCustomAttr]'
})
export class CustomAttrDirective {

  constructor(public elem: ElementRef,public  renderer: Renderer2) {


  }

  ngOnInit()
  {
    //this.elem.nativeElement.style.backgroundColor = 'pink';
    /*directly changing DOM is not recommended, better way is to use Renderer2
      as angular might not always run in browser, it might also work with service-workers
      and there it might not have access to the DOM! and you might get error in few usecases.
    */
    this.renderer.setStyle(this.elem.nativeElement,'background-color','green');

    //for more functionality of renderer2 refer to https://angular.io/api/core/Renderer2
  }

}
