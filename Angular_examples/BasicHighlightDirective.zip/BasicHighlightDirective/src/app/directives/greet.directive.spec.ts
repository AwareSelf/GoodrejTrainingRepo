import { GreetDirective } from './greet.directive';

describe('GreetDirective', () => {
  it('should create an instance', () => {
    const directive = new GreetDirective();
    expect(directive).toBeTruthy();
  });
});
