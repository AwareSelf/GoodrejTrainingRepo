import { AttrCustomHostbinding1Directive } from './attr-custom-hostbinding1.directive';

describe('AttrCustomHostbinding1Directive', () => {
  it('should create an instance', () => {
    const directive = new AttrCustomHostbinding1Directive();
    expect(directive).toBeTruthy();
  });
});
