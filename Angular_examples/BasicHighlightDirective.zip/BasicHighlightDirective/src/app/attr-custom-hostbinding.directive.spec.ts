import { AttrCustomHostbindingDirective } from './attr-custom-hostbinding.directive';

describe('AttrCustomHostbindingDirective', () => {
  it('should create an instance', () => {
    const directive = new AttrCustomHostbindingDirective();
    expect(directive).toBeTruthy();
  });
});
