import { AttrCustomHostbinding2Directive } from './attr-custom-hostbinding2.directive';

describe('AttrCustomHostbinding2Directive', () => {
  it('should create an instance', () => {
    const directive = new AttrCustomHostbinding2Directive();
    expect(directive).toBeTruthy();
  });
});
