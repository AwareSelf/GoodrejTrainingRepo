import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { GreetDirective } from './directives/greet.directive';
import { CustomAttrDirective } from './directives/custom-attr.directive';
import { AttrCustomHostlistenerDirective } from './attr-custom-hostlistener.directive';
import { AttrCustomHostbindingDirective } from './attr-custom-hostbinding.directive';
import { AttrCustomHostbinding1Directive } from './attr-custom-hostbinding1.directive';
import { AttrCustomHostbinding2Directive } from './attr-custom-hostbinding2.directive';
import { CustomStructuralDirective } from './custom-structural.directive';

//Note: FormsModule is required only during two-way binding - using ngModel

@NgModule({
  declarations: [
    AppComponent,
    GreetDirective,
    CustomAttrDirective,
    AttrCustomHostlistenerDirective,
    AttrCustomHostbindingDirective,
    AttrCustomHostbinding1Directive,
    AttrCustomHostbinding2Directive,
    CustomStructuralDirective
  ],
  imports: [
    BrowserModule,
    FormsModule],

  bootstrap: [AppComponent]
})
export class AppModule { }
