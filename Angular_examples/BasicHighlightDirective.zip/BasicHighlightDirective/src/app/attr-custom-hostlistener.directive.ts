import { Directive, ElementRef, HostListener, OnInit, Renderer2,AfterViewInit } from '@angular/core';

@Directive({
  selector: '[appAttrCustomHostlistener]'
})
export class AttrCustomHostlistenerDirective implements OnInit,AfterViewInit {

  constructor(public elem:ElementRef,public renderer:Renderer2) {

  }

  ngOnInit() : void
  {
    console.log('ngOnInit called');
  }

  ngAfterViewInit() : void
  {
    console.log('ngAfterViewInit called');
  }

  @HostListener('mouseenter') mouseover(eventData:Event)
  {
     this.renderer.setStyle(this.elem.nativeElement,'backgroundColor','blue');
  }


  @HostListener('mouseleave') mouseover1(eventData:Event)
  {
    this.renderer.setStyle(this.elem.nativeElement,'backgroundColor','transparent');
  }

}
