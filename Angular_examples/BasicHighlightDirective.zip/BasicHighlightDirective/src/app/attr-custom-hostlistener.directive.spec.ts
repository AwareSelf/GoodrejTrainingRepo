import { AttrCustomHostlistenerDirective } from './attr-custom-hostlistener.directive';

describe('AttrCustomHostlistenerDirective', () => {
  it('should create an instance', () => {
    const directive = new AttrCustomHostlistenerDirective();
    expect(directive).toBeTruthy();
  });
});
