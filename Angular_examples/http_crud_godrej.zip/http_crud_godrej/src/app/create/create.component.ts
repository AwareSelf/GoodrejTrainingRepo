import { Component, OnInit } from '@angular/core';
import {Book} from '../Book';
import { HttpClient,HttpHeaders} from '@angular/common/http';
import { Router } from '@angular/router';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css'],
 // providers:[CrudService]
})
export class CreateComponent implements OnInit {

  book!:Book;

  router!:Router;
  crud!:CrudService;


  constructor(router:Router,crud:CrudService) {
    this.book = new Book();
   
     this.router = router;
     this.crud =  crud;
   
   }

  ngOnInit(): void {
  }

  addbook():void{

    this.crud.addbook(this.book).subscribe(
    {
      next:()=>{
        console.log('book with id:'+this.book.bookid+' posted successfully');
        this.router.navigateByUrl('home');
      },
      error:(e)=>{
        console.log('error while posting book with bookid:'+this.book.bookid);
      },
      complete:()=>{
        console.log('post request for bookid:'+this.book.bookid+' completed.');
      }
    } //group of callbacks for success,failure and completion
  )
  
   /* navigating here is incorrect logic as we should not navigate when call is made
     rather we should only navigate when the http call is successful. so add navigate in
     success callback method */
    // this.router.navigateByUrl('home');

  }//end of add book method

}
