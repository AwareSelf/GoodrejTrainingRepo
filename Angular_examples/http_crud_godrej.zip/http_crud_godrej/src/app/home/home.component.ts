import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs'
import { Book } from '../Book';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
 // providers:[CrudService]
})
export class HomeComponent implements OnInit {
  http!:HttpClient;
  baseUrl!:string;
  bookarr!:Book[];
  crud!:CrudService;
  


  constructor(http:HttpClient,crud:CrudService) { 
    this.http =  http;
    this.baseUrl = "http://localhost:5000/";
    this.bookarr = [];
    this.crud = crud;
    
  }

  ngOnInit(): void {

     this.crud.getAllBooks().subscribe(
      {
        next:(bookarr:Book[])=>{
          this.bookarr = bookarr;

          console.log('getallbooks http call is successful'+this.bookarr[0].bookid);

        },
        error:(e)=>{
          console.log('getallbooks http call failed:error'+e);

        },
        complete:()=>{
          console.log('getAllBooks http call completed..');

        }
      }      
     )
  }

  getAllBooks():void {
    this.crud.getAllBooks().subscribe(
      {
        next:(bookarr:Book[])=>{
          this.bookarr = bookarr;

          console.log('getallbooks http call is successful'+this.bookarr[0].bookid);

        },
        error:(e)=>{
          console.log('getallbooks http call failed:error'+e);

        },
        complete:()=>{
          console.log('getAllBooks http call completed..');

        }
      }      
     )

  }

  deleteBook(bookid:number)
  {
     this.crud.deleteBook(bookid).subscribe(
      {
        next:()=>{
            console.log('deletebook http call is successful for bookid'+bookid);
            this.getAllBooks();

        },
        error:(e)=>{
          console.log('deletebook http call failed:error'+e);

        },
        complete:()=>{
          console.log('delete Book http call completed..');

        }
      }   
     )
  }

}
