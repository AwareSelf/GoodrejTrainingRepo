import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {Book} from './Book';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})


//@Injectable()
export class CrudService {

 // bookarr:Book[];
  http!:HttpClient;
  baseUrl!:string;
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    }) 
  }

  constructor(http:HttpClient) {
   // this.bookarr = [];
    this.http = http;
    this.baseUrl = "http://localhost:5000/books";
   }


   addbook(b:Book):Observable<Book>{

    console.log(JSON.stringify(b));
    return this.http.post<Book>(this.baseUrl,JSON.stringify(b),this.httpOptions);
    

  }

  getAllBooks():Observable<Book[]>
  {
    console.log('inside crud service getAllBooks method');
    return this.http.get<Book[]>(this.baseUrl);
  }

  deleteBook(bookid:number)
  {
    console.log('inside crud service delteBook method');
    return this.http.delete(this.baseUrl+'/'+bookid);
   
  }

}
