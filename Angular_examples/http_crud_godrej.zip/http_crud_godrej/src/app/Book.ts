export class Book {

   public bookid!:number;
   public bookname!:string;
   public bookauthor!:string


    constructor(bookid:number=0,bookname:string='core java',bookauthor:string='namrata')
    {
        this.bookid = bookid;
        this.bookname = bookname;
        this.bookauthor = bookauthor;
    }

   
}