package com.namrata.springboot.myfirstwebapp.model;

public class Greet {
	
	
	private String message;
	
	

	public Greet(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
    
}
