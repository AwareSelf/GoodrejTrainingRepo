package com.namrata.springbootdemo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootdemo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
